package com.example.pessoa_swagger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PessoaSwaggerApplicationTests {

	@Test
	void contextLoads() {
	}

}
