package com.example.pessoa_swagger.service;

import com.example.pessoa_swagger.entity.Pessoa;
import com.example.pessoa_swagger.repository.PessoaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PessoaService {

    @Autowired
    PessoaRepository repository;

    public void post(Pessoa pessoa) {
        repository.save(pessoa);
    }

    public List<Pessoa> findAll() {
        return repository.findAll();
    }

    public Optional<Pessoa> getById(Long id) {
        return repository.findById(id);
    }

    public Pessoa Put(long id, Pessoa newPessoa) throws Exception {
        Optional<Pessoa> oldPessoa = repository.findById(id);
        if(oldPessoa.isPresent()){
            Pessoa pessoa = oldPessoa.get();
            pessoa.setNome(newPessoa.getNome());
            pessoa.setAge(newPessoa.getAge());
            pessoa.setEmail(newPessoa.getEmail());
            return repository.save(pessoa);
        }
        else
            throw new Exception("Pessoa não encontrada");
    }

    public void delete(long id) throws Exception {
        Optional<Pessoa> pessoa = repository.findById(id);
        if(pessoa.isPresent()){
            repository.delete(pessoa.get());
        } else {
            throw new Exception("Pessoa não encontrada");
        }
    }


}