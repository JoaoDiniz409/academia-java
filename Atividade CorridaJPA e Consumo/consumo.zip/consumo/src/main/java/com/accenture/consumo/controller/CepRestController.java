package com.accenture.consumo.controller;

import com.accenture.consumo.interfaces.CepService;
import com.accenture.consumo.interfaces.EnderecoRepository;
import com.accenture.consumo.model.Endereco;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@RestController
public class CepRestController {

    @Autowired
    private CepService cepService;

    @Autowired
    private EnderecoRepository repository;

    @GetMapping("/{cep}")
    public ResponseEntity<Endereco> getCep(@PathVariable String cep) {

        Endereco endereco = cepService.buscaEnderecoPorCep(cep);

        return endereco != null ? ResponseEntity.ok().body(repository.save(endereco)) : ResponseEntity.notFound().build();
    }

    @GetMapping("/listar")
    public ModelAndView getAll() {

        List<Endereco> lista = repository.findAll();
        ModelAndView modelAndView = new ModelAndView("enderecos");
        modelAndView.addObject("enderecos", lista);
        return modelAndView;
    }



}
