package acc.br.studentList.repository;

import acc.br.studentList.model.Student;
import org.springframework.data.repository.CrudRepository;

public interface StudentRepository extends CrudRepository<Student, Integer> {
}
