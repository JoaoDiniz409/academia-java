package acc.br;

import acc.br.model.Fruta;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;

import java.net.URI;
import java.util.List;

@Path("/frutas")
public class FrutaResource {
    private static final Logger LOG = Logger.getLogger(FrutaResource.class);

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Fruta> list() {
        LOG.info("GET Log funcionando");
        return Fruta.listAll();
    }

    @POST
    @Transactional
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response add(Fruta fruta) {
        LOG.info("POST Log funcionando");
        fruta.persist();
        return Response.created(URI.create("/frutas/" + fruta.id)).entity(fruta).build();
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    public Response delete(@PathParam("id") Long id) {
        LOG.info("DELETE Log funcionando");
        Fruta fruta = Fruta.findById(id);
        if (fruta == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        fruta.delete();
        return Response.noContent().build();
    }
}
